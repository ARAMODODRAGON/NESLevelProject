﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public partial class Mario {
    [Header("Ground Movement")]
    public float maxWalkSpeed;
    public float maxRunSpeed;
    public float maxPSpeed;

    private void FixedGroundUpdate() {
        
    }

}
